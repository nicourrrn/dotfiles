require 'plugins'
require 'ncoq'
require 'cfg'
require 'hotkeys'


-- vim.cmd[[colorscheme neon]]
vim.o.background = "dark"
vim.cmd[[colorscheme gruvbox]]

